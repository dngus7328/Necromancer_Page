using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class EnemyUnitBase : MonoBehaviour
{
    public enum TargetType
    {
        Nearest,
        SummonOnly,
        HighestDefense,
        HighestMaxHealth,
        Farthest,
        RibelOnly,
        Escape
    }

    [Header("�⺻ �ɷ�ġ")]
    [SerializeField] private float maxHealth = 50f;

    [Header("óġ ����")]
    [SerializeField] private float manaReward = 5f;

    [Header("�̵�")]
    [SerializeField] private float moveSpeed = 3f;

    [Header("����")]
    [SerializeField] private float attackDamage = 10f;
    [SerializeField] private float attackRange = 0.8f;
    [SerializeField] private float attackInterval = 1.2f;

    [Header("Ÿ�� ����")]
    [SerializeField] private TargetType targetType = TargetType.Nearest;

    [SerializeField] private LayerMask summonLayer;

    [Tooltip("�켱 ���� ����� �߰��� �� �ִ� �Ÿ�")]
    [SerializeField] private float detectionRange = 7f;

    [Tooltip("���� �켱 Ÿ���� �����ϴ� �Ÿ�")]
    [SerializeField] private float disengageRange = 10f;

    [SerializeField] private float searchInterval = 0.2f;

    private Rigidbody2D rb;

    private Transform ribel;
    private Transform currentTarget;

    private float currentHealth;
    private float attackTimer;
    private float searchTimer;

    private bool isDead;

    public float CurrentHealth => currentHealth;
    public float MaxHealth => maxHealth;

    public float HealthRatio
    {
        get
        {
            if (maxHealth <= 0f)
            {
                return 0f;
            }

            return Mathf.Clamp01(
                currentHealth / maxHealth
            );
        }
    }

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        currentHealth = maxHealth;
    }

    private void Start()
    {
        FindRibel();

        // ���� ���� �⺻ ��ǥ�� ������ ����
        SetRibelAsTarget();
    }

    private void Update()
    {
        if (isDead)
        {
            return;
        }

        UpdateTimers();
        UpdateTarget();
    }

    private void FixedUpdate()
    {
        if (isDead)
        {
            return;
        }

        UpdateMovement();
    }

    // =========================================================
    // ���� ã��
    // =========================================================

    private void FindRibel()
    {
        if (ribel != null)
        {
            return;
        }

        GameObject ribelObject =
            GameObject.FindGameObjectWithTag("Player");

        if (ribelObject != null)
        {
            ribel = ribelObject.transform;
        }
    }

    private void SetRibelAsTarget()
    {
        if (ribel == null)
        {
            FindRibel();
        }

        currentTarget = ribel;
    }

    // =========================================================
    // ���� / ���
    // =========================================================

    public void TakeDamage(float damage)
    {
        if (isDead || damage <= 0f)
        {
            return;
        }

        currentHealth -= damage;

        if (currentHealth < 0f)
        {
            currentHealth = 0f;
        }

        if (currentHealth <= 0f)
        {
            Die();
        }
    }

    private void Die()
    {
        if (isDead)
        {
            return;
        }

        isDead = true;
        currentHealth = 0f;

        StopMovement();

        if (SummonManager.Instance != null)
        {
            SummonManager.Instance.AddMana(
                manaReward
            );
        }

        Destroy(gameObject);
    }

    // =========================================================
    // Ÿ�� ����
    // =========================================================

    private void UpdateTarget()
    {
        if (targetType == TargetType.Escape)
        {
            currentTarget = null;
            return;
        }

        searchTimer -= Time.deltaTime;

        if (searchTimer > 0f)
        {
            return;
        }

        searchTimer = searchInterval;

        // ���� Ÿ���� �����
        if (currentTarget == null ||
            !currentTarget.gameObject.activeInHierarchy)
        {
            SetRibelAsTarget();
            return;
        }

        // ������ �����ϴ� ��
        if (targetType == TargetType.RibelOnly)
        {
            SetRibelAsTarget();
            return;
        }

        // =====================================================
        // �̹� ��ȯ���� �ϳ� Ÿ������ ��Ҵٸ�
        // �Ժη� �ٸ� ��ȯ���� ����Ÿ�� ����
        // =====================================================

        SummonUnitBase currentSummon =
            currentTarget.GetComponent<SummonUnitBase>();

        if (currentSummon != null)
        {
            float distance =
                Vector2.Distance(
                    transform.position,
                    currentTarget.position
                );

            // �ʹ� �־��� ��쿡�� ����
            if (distance > disengageRange)
            {
                SetRibelAsTarget();
            }
            else
            {
                return;
            }
        }

        // =====================================================
        // ���� ������ �Ѱ� ���� ����
        // �� �켱���� ��ȯ�� Ž��
        // =====================================================

        if (currentTarget == ribel)
        {
            Transform preferredTarget =
                FindPreferredTarget();

            if (preferredTarget != null &&
                preferredTarget != ribel)
            {
                currentTarget =
                    preferredTarget;
            }
        }
    }

    // =========================================================
    // ������ �켱 Ÿ��
    // =========================================================

    private Transform FindPreferredTarget()
    {
        switch (targetType)
        {
            case TargetType.Nearest:
                return FindNearestSummon();

            case TargetType.SummonOnly:
                return FindNearestSummon();

            case TargetType.HighestDefense:
                return FindHighestDefenseSummon();

            case TargetType.HighestMaxHealth:
                return FindHighestMaxHealthSummon();

            case TargetType.Farthest:
                return FindFarthestSummon();
        }

        return null;
    }

    // =========================================================
    // ���� ����� ��ȯ��
    // =========================================================

    private Transform FindNearestSummon()
    {
        Collider2D[] summons =
            Physics2D.OverlapCircleAll(
                transform.position,
                detectionRange,
                summonLayer
            );

        Transform bestTarget = null;
        float bestDistance = Mathf.Infinity;

        for (int i = 0; i < summons.Length; i++)
        {
            SummonUnitBase summon =
                summons[i].GetComponentInParent<SummonUnitBase>();

            if (summon == null)
            {
                continue;
            }

            float distance =
                Vector2.SqrMagnitude(
                    (Vector2)summon.transform.position -
                    rb.position
                );

            if (distance < bestDistance)
            {
                bestDistance = distance;
                bestTarget = summon.transform;
            }
        }

        return bestTarget;
    }

    // =========================================================
    // ���� ���� ��ȯ��
    // =========================================================

    private Transform FindHighestDefenseSummon()
    {
        Collider2D[] summons =
            Physics2D.OverlapCircleAll(
                transform.position,
                detectionRange,
                summonLayer
            );

        SummonUnitBase bestSummon = null;
        float highestDefense = float.MinValue;

        for (int i = 0; i < summons.Length; i++)
        {
            SummonUnitBase summon =
                summons[i].GetComponentInParent<SummonUnitBase>();

            if (summon == null)
            {
                continue;
            }

            if (summon.Defense > highestDefense)
            {
                highestDefense = summon.Defense;
                bestSummon = summon;
            }
        }

        return bestSummon != null
            ? bestSummon.transform
            : null;
    }

    // =========================================================
    // �ִ� HP ���� ��ȯ��
    // =========================================================

    private Transform FindHighestMaxHealthSummon()
    {
        Collider2D[] summons =
            Physics2D.OverlapCircleAll(
                transform.position,
                detectionRange,
                summonLayer
            );

        SummonUnitBase bestSummon = null;
        float highestHealth = float.MinValue;

        for (int i = 0; i < summons.Length; i++)
        {
            SummonUnitBase summon =
                summons[i].GetComponentInParent<SummonUnitBase>();

            if (summon == null)
            {
                continue;
            }

            if (summon.MaxHealth > highestHealth)
            {
                highestHealth = summon.MaxHealth;
                bestSummon = summon;
            }
        }

        return bestSummon != null
            ? bestSummon.transform
            : null;
    }

    // =========================================================
    // ���� �� ��ȯ��
    // =========================================================

    private Transform FindFarthestSummon()
    {
        Collider2D[] summons =
            Physics2D.OverlapCircleAll(
                transform.position,
                detectionRange,
                summonLayer
            );

        Transform bestTarget = null;
        float farthestDistance = -1f;

        for (int i = 0; i < summons.Length; i++)
        {
            SummonUnitBase summon =
                summons[i].GetComponentInParent<SummonUnitBase>();

            if (summon == null)
            {
                continue;
            }

            float distance =
                Vector2.SqrMagnitude(
                    (Vector2)summon.transform.position -
                    rb.position
                );

            if (distance > farthestDistance)
            {
                farthestDistance = distance;
                bestTarget = summon.transform;
            }
        }

        return bestTarget;
    }

    // =========================================================
    // �̵�
    // =========================================================

    private void UpdateMovement()
    {
        if (targetType == TargetType.Escape)
        {
            StopMovement();
            return;
        }

        if (currentTarget == null)
        {
            SetRibelAsTarget();

            if (currentTarget == null)
            {
                StopMovement();
                return;
            }
        }

        float distance =
            Vector2.Distance(
                rb.position,
                currentTarget.position
            );

        if (distance <= attackRange)
        {
            StopMovement();
            TryAttack();
            return;
        }

        Vector2 nextPosition =
            Vector2.MoveTowards(
                rb.position,
                currentTarget.position,
                moveSpeed * Time.fixedDeltaTime
            );

        rb.MovePosition(nextPosition);
    }

    // =========================================================
    // ����
    // =========================================================

    private void TryAttack()
    {
        if (attackTimer > 0f ||
            currentTarget == null)
        {
            return;
        }

        SummonUnitBase summon =
            currentTarget.GetComponent<SummonUnitBase>();

        if (summon != null)
        {
            summon.TakeDamage(
                attackDamage
            );

            attackTimer =
                attackInterval;

            return;
        }

        if (currentTarget.CompareTag("Player"))
        {
            RibelHealth health =
                currentTarget.GetComponent<RibelHealth>();

            if (health != null)
            {
                health.TakeDamage(
                    attackDamage
                );
            }

            attackTimer =
                attackInterval;
        }
    }

    private void UpdateTimers()
    {
        if (attackTimer > 0f)
        {
            attackTimer -=
                Time.deltaTime;
        }
    }

    private void StopMovement()
    {
        rb.velocity = Vector2.zero;
        rb.angularVelocity = 0f;
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        maxHealth =
            Mathf.Max(1f, maxHealth);

        manaReward =
            Mathf.Max(0f, manaReward);

        moveSpeed =
            Mathf.Max(0f, moveSpeed);

        attackDamage =
            Mathf.Max(0f, attackDamage);

        attackRange =
            Mathf.Max(0.05f, attackRange);

        attackInterval =
            Mathf.Max(0.05f, attackInterval);

        detectionRange =
            Mathf.Max(0.1f, detectionRange);

        disengageRange =
            Mathf.Max(
                detectionRange,
                disengageRange
            );

        searchInterval =
            Mathf.Max(0.05f, searchInterval);
    }
#endif
}