using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    [Header("���� ���")]
    [SerializeField] private Transform target;

    [Header("ī�޶� ��ġ")]
    [SerializeField] private Vector3 offset = new Vector3(0f, 0f, -10f);

    [Header("�̼� ��鸲 ����")]
    [Tooltip("�� �Ÿ����� ���� �������� ī�޶� ����")]
    [SerializeField] private float deadZone = 0.01f;

    private void LateUpdate()
    {
        if (target == null)
        {
            return;
        }

        Vector3 desiredPosition =
            target.position + offset;

        Vector2 currentXY =
            new Vector2(
                transform.position.x,
                transform.position.y
            );

        Vector2 desiredXY =
            new Vector2(
                desiredPosition.x,
                desiredPosition.y
            );

        float distance =
            Vector2.Distance(
                currentXY,
                desiredXY
            );

        // ���� �̼��� ���̴� ����
        if (distance < deadZone)
        {
            return;
        }

        transform.position =
            new Vector3(
                desiredPosition.x,
                desiredPosition.y,
                offset.z
            );
    }
}