using UnityEngine;

public class EnemyHealthBar : MonoBehaviour
{
    [Header("���")]
    [SerializeField] private EnemyUnitBase enemy;

    [Header("ü�¹�")]
    [SerializeField] private Transform fill;

    [Tooltip("ü���� ���� á�� �� Fill�� X ũ��")]
    [SerializeField] private float fullWidth = 0.8f;

    private Vector3 originalFillScale;
    private Vector3 originalFillPosition;

    private void Awake()
    {
        if (enemy == null)
        {
            enemy =
                GetComponentInParent<EnemyUnitBase>();
        }

        if (fill != null)
        {
            originalFillScale = fill.localScale;
            originalFillPosition = fill.localPosition;
        }
    }

    private void LateUpdate()
    {
        UpdateHealthBar();
    }

    private void UpdateHealthBar()
    {
        if (enemy == null || fill == null)
        {
            return;
        }

        float ratio = enemy.HealthRatio;

        Vector3 newScale =
            originalFillScale;

        newScale.x =
            originalFillScale.x * ratio;

        fill.localScale = newScale;

        // ��� Pivot�̾
        // ������ �κи� �پ�� ��ó�� ���̵��� ��ġ ����
        float lostWidth =
            fullWidth * (1f - ratio);

        Vector3 newPosition =
            originalFillPosition;

        newPosition.x =
            originalFillPosition.x -
            (lostWidth * 0.5f);

        fill.localPosition =
            newPosition;
    }
}