using System.Collections;
using UnityEngine;

public class RibelHealth : MonoBehaviour
{
    [Header("ü��")]
    [SerializeField] private float maxHealth = 100f;

    [Header("�ǰ� ����")]
    [Tooltip("�ǰ� ���� ���� ª�� ���� ���̴� �ð�")]
    [SerializeField] private float hitPauseTime = 0.08f;

    [Tooltip("���� ������ �����Ǵ� �ð�")]
    [SerializeField] private float redFlashTime = 0.12f;

    [Tooltip("�ǰ� �� ��ü ���� �ð�")]
    [SerializeField] private float invincibleTime = 0.8f;

    [Header("�ǰ� ����")]
    [SerializeField]
    private Color hitColor =
        new Color(1f, 0.2f, 0.2f, 1f);

    [Header("���� ǥ��")]
    [Tooltip("���� �� �����̴� ����")]
    [SerializeField] private float blinkInterval = 0.08f;

    [Tooltip("������ �� ������")]
    [Range(0f, 1f)]
    [SerializeField] private float blinkAlpha = 0.35f;

    private float currentHealth;

    private bool isInvincible;
    private bool isDead;

    private SpriteRenderer spriteRenderer;
    private RibelController ribelController;

    private Color originalColor;

    public float CurrentHealth => currentHealth;
    public float MaxHealth => maxHealth;
    public bool IsInvincible => isInvincible;

    private void Awake()
    {
        currentHealth = maxHealth;

        spriteRenderer =
            GetComponent<SpriteRenderer>();

        ribelController =
            GetComponent<RibelController>();

        if (spriteRenderer != null)
        {
            originalColor =
                spriteRenderer.color;
        }
    }

    // =========================================================
    // ����
    // =========================================================

    public void TakeDamage(float damage)
    {
        if (damage <= 0f)
        {
            return;
        }

        if (isDead)
        {
            return;
        }

        if (isInvincible)
        {
            return;
        }

        currentHealth -= damage;

        if (currentHealth < 0f)
        {
            currentHealth = 0f;
        }

        Debug.Log(
            $"���� ���� {damage} | HP {currentHealth}/{maxHealth}"
        );

        if (currentHealth <= 0f)
        {
            Die();
            return;
        }

        StartCoroutine(
            HitRoutine()
        );
    }

    // =========================================================
    // �ǰ� + ���� ����
    // =========================================================

    private IEnumerator HitRoutine()
    {
        isInvincible = true;

        // -----------------------------------------
        // 1. �ǰ� ���
        // -----------------------------------------

        if (ribelController != null)
        {
            ribelController.PlayHitMotion();
        }

        // -----------------------------------------
        // 2. ��� ��
        // -----------------------------------------

        if (hitPauseTime > 0f)
        {
            yield return new WaitForSeconds(
                hitPauseTime
            );
        }

        // -----------------------------------------
        // 3. �Ӱ� ǥ��
        // -----------------------------------------

        if (spriteRenderer != null)
        {
            spriteRenderer.color =
                hitColor;
        }

        if (redFlashTime > 0f)
        {
            yield return new WaitForSeconds(
                redFlashTime
            );
        }

        // -----------------------------------------
        // 4. ���� �� ����
        // -----------------------------------------

        RestoreOriginalColor();

        // -----------------------------------------
        // 5. ���� ���� �ð� ���� ������
        // -----------------------------------------

        float remainingInvincibleTime =
            invincibleTime -
            hitPauseTime -
            redFlashTime;

        if (remainingInvincibleTime > 0f)
        {
            yield return StartCoroutine(
                BlinkRoutine(
                    remainingInvincibleTime
                )
            );
        }

        // -----------------------------------------
        // 6. ���� ����
        // -----------------------------------------

        RestoreOriginalColor();

        isInvincible = false;
    }

    // =========================================================
    // ���� ������
    // =========================================================

    private IEnumerator BlinkRoutine(
        float duration)
    {
        if (spriteRenderer == null)
        {
            yield return new WaitForSeconds(
                duration
            );

            yield break;
        }

        float elapsed = 0f;

        bool transparent = false;

        while (elapsed < duration)
        {
            transparent =
                !transparent;

            Color color =
                originalColor;

            color.a =
                transparent
                    ? blinkAlpha
                    : originalColor.a;

            spriteRenderer.color =
                color;

            float waitTime =
                Mathf.Min(
                    blinkInterval,
                    duration - elapsed
                );

            if (waitTime <= 0f)
            {
                break;
            }

            yield return new WaitForSeconds(
                waitTime
            );

            elapsed += waitTime;
        }
    }

    // =========================================================
    // ���� �� ����
    // =========================================================

    private void RestoreOriginalColor()
    {
        if (spriteRenderer != null)
        {
            spriteRenderer.color =
                originalColor;
        }
    }

    // =========================================================
    // ȸ��
    // =========================================================

    public void Heal(float amount)
    {
        if (amount <= 0f ||
            isDead)
        {
            return;
        }

        currentHealth += amount;

        if (currentHealth > maxHealth)
        {
            currentHealth = maxHealth;
        }
    }

    // =========================================================
    // ���
    // =========================================================

    private void Die()
    {
        if (isDead)
        {
            return;
        }

        isDead = true;
        isInvincible = true;

        currentHealth = 0f;

        StopAllCoroutines();

        RestoreOriginalColor();

        if (ribelController != null)
        {
            ribelController.PlayDeathMotion();
        }

        Debug.Log("���� ���");

        // ���ӿ����� ���߿� ����
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        maxHealth =
            Mathf.Max(
                1f,
                maxHealth
            );

        hitPauseTime =
            Mathf.Max(
                0f,
                hitPauseTime
            );

        redFlashTime =
            Mathf.Max(
                0f,
                redFlashTime
            );

        invincibleTime =
            Mathf.Max(
                0f,
                invincibleTime
            );

        blinkInterval =
            Mathf.Max(
                0.02f,
                blinkInterval
            );

        blinkAlpha =
            Mathf.Clamp01(
                blinkAlpha
            );
    }
#endif
}