using UnityEngine;

public class SummonRangeIndicator : MonoBehaviour
{
    [Header("ǥ���� ��Ÿ� ������Ʈ")]
    [SerializeField] private GameObject rangeVisual;

    private void Start()
    {
        if (rangeVisual != null)
        {
            rangeVisual.SetActive(false);
        }
    }

    private void Update()
    {
        if (rangeVisual == null)
        {
            return;
        }

        bool shouldShow =
            SummonManager.Instance != null &&
            SummonManager.Instance.IsPlacementMode;

        if (rangeVisual.activeSelf != shouldShow)
        {
            rangeVisual.SetActive(shouldShow);
        }
    }
}