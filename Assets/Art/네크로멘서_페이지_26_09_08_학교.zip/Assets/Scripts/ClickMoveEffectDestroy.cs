using UnityEngine;

[RequireComponent(typeof(Animator))]
public class ClickMoveEffectDestroy : MonoBehaviour
{
    private Animator animator;
    private bool started;

    private void Awake()
    {
        animator = GetComponent<Animator>();
    }

    private void Update()
    {
        if (animator == null)
        {
            Destroy(gameObject);
            return;
        }

        AnimatorStateInfo state = animator.GetCurrentAnimatorStateInfo(0);

        // Animator�� ���� ����� ������ �ں��� �˻�
        if (state.normalizedTime > 0f)
        {
            started = true;
        }

        // �ִϸ��̼� 1ȸ ��� �Ϸ�
        if (started && state.normalizedTime >= 1f && !animator.IsInTransition(0))
        {
            Destroy(gameObject);
        }
    }
}