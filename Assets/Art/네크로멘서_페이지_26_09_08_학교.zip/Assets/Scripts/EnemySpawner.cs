using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    [Header("������ ��")]
    [SerializeField] private GameObject enemyPrefab;

    [Header("�׽�Ʈ ���� ����")]
    [Tooltip("�Ѹ� ���� ��� �����մϴ�.")]
    [SerializeField] private bool endlessTestMode = true;

    [Tooltip("���ÿ� ������� �� �ִ� �ִ� ��")]
    [SerializeField] private int maxAliveEnemies = 20;

    [Tooltip("�� �� ���� ����")]
    [SerializeField] private float spawnInterval = 0.5f;

    [Header("�Ϲ� �׽�Ʈ")]
    [Tooltip("���� ��尡 ���� ���� �� ������ �� �� ��")]
    [SerializeField] private int spawnCount = 5;

    [Header("ī�޶� �ٱ� ����")]
    [SerializeField] private float minOutsideDistance = 1.5f;
    [SerializeField] private float maxOutsideDistance = 4f;

    [Header("���� �Ÿ�")]
    [SerializeField] private float minDistanceFromRibel = 4f;
    [SerializeField] private float minDistanceFromSummons = 2f;

    [Header("��ȯ��")]
    [SerializeField] private LayerMask summonLayer;

    [Header("��ֹ�")]
    [SerializeField] private LayerMask blockedLayers;
    [SerializeField] private float spawnCheckRadius = 0.4f;

    [Header("���� ��ġ Ž��")]
    [SerializeField] private int maxSpawnAttempts = 50;

    [Header("����")]
    [Tooltip("Play ���۰� ���ÿ� ���� ����")]
    [SerializeField] private bool spawnOnStart = true;

    private Camera mainCamera;
    private Transform ribel;

    private float spawnTimer;

    private int remainingSpawnCount;
    private bool spawning;

    private void Awake()
    {
        mainCamera = Camera.main;

        FindRibel();
    }

    private void Start()
    {
        if (spawnOnStart)
        {
            StartSpawnWave();
        }
    }

    private void Update()
    {
        if (!spawning)
        {
            return;
        }

        spawnTimer -= Time.deltaTime;

        if (spawnTimer > 0f)
        {
            return;
        }

        spawnTimer = spawnInterval;

        if (endlessTestMode)
        {
            UpdateEndlessSpawn();
        }
        else
        {
            UpdateNormalSpawn();
        }
    }

    // =========================================================
    // ���� ����
    // =========================================================

    public void StartSpawnWave()
    {
        if (enemyPrefab == null)
        {
            Debug.LogWarning(
                $"{gameObject.name}: Enemy Prefab�� �����ϴ�."
            );

            return;
        }

        FindRibel();

        remainingSpawnCount =
            spawnCount;

        spawnTimer = 0f;
        spawning = true;
    }

    // =========================================================
    // ���� �׽�Ʈ
    // =========================================================

    private void UpdateEndlessSpawn()
    {
        int aliveEnemies =
            FindObjectsOfType<EnemyUnitBase>().Length;

        if (aliveEnemies >= maxAliveEnemies)
        {
            return;
        }

        TrySpawnEnemy();
    }

    // =========================================================
    // �Ϲ� ����
    // =========================================================

    private void UpdateNormalSpawn()
    {
        if (remainingSpawnCount <= 0)
        {
            spawning = false;
            return;
        }

        if (TrySpawnEnemy())
        {
            remainingSpawnCount--;
        }
    }

    // =========================================================
    // �� ����
    // =========================================================

    private bool TrySpawnEnemy()
    {
        for (int i = 0; i < maxSpawnAttempts; i++)
        {
            Vector2 position =
                GetRandomOutsideCameraPosition();

            if (!IsValidSpawnPosition(position))
            {
                continue;
            }

            Instantiate(
                enemyPrefab,
                position,
                Quaternion.identity
            );

            return true;
        }

        return false;
    }

    // =========================================================
    // ī�޶� �� ���� ��ǥ
    // =========================================================

    private Vector2 GetRandomOutsideCameraPosition()
    {
        if (mainCamera == null)
        {
            mainCamera = Camera.main;
        }

        float cameraHeight =
            mainCamera.orthographicSize * 2f;

        float cameraWidth =
            cameraHeight * mainCamera.aspect;

        Vector2 center =
            mainCamera.transform.position;

        float halfWidth =
            cameraWidth * 0.5f;

        float halfHeight =
            cameraHeight * 0.5f;

        float distance =
            Random.Range(
                minOutsideDistance,
                maxOutsideDistance
            );

        int side =
            Random.Range(0, 4);

        switch (side)
        {
            case 0:
                return new Vector2(
                    Random.Range(
                        center.x - halfWidth,
                        center.x + halfWidth
                    ),
                    center.y +
                    halfHeight +
                    distance
                );

            case 1:
                return new Vector2(
                    Random.Range(
                        center.x - halfWidth,
                        center.x + halfWidth
                    ),
                    center.y -
                    halfHeight -
                    distance
                );

            case 2:
                return new Vector2(
                    center.x -
                    halfWidth -
                    distance,
                    Random.Range(
                        center.y - halfHeight,
                        center.y + halfHeight
                    )
                );

            default:
                return new Vector2(
                    center.x +
                    halfWidth +
                    distance,
                    Random.Range(
                        center.y - halfHeight,
                        center.y + halfHeight
                    )
                );
        }
    }

    // =========================================================
    // ��ġ �˻�
    // =========================================================

    private bool IsValidSpawnPosition(
        Vector2 position)
    {
        if (ribel != null)
        {
            float distance =
                Vector2.Distance(
                    position,
                    ribel.position
                );

            if (distance <
                minDistanceFromRibel)
            {
                return false;
            }
        }

        Collider2D[] nearbySummons =
            Physics2D.OverlapCircleAll(
                position,
                minDistanceFromSummons,
                summonLayer
            );

        for (int i = 0;
             i < nearbySummons.Length;
             i++)
        {
            SummonUnitBase summon =
                nearbySummons[i]
                    .GetComponentInParent<SummonUnitBase>();

            if (summon != null)
            {
                return false;
            }
        }

        // ��ȯ�� Ž�� ���� �ȿ��� ���� ����
        SummonUnitBase[] summons =
            FindObjectsOfType<SummonUnitBase>();

        for (int i = 0; i < summons.Length; i++)
        {
            SummonUnitBase summon =
                summons[i];

            if (summon == null)
            {
                continue;
            }

            float distance =
                Vector2.Distance(
                    position,
                    summon.transform.position
                );

            if (distance <=
                summon.DetectionRange)
            {
                return false;
            }
        }

        Collider2D blocked =
            Physics2D.OverlapCircle(
                position,
                spawnCheckRadius,
                blockedLayers
            );

        if (blocked != null)
        {
            return false;
        }

        return true;
    }

    private void FindRibel()
    {
        GameObject objectRibel =
            GameObject.FindGameObjectWithTag(
                "Player"
            );

        if (objectRibel != null)
        {
            ribel =
                objectRibel.transform;
        }
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        maxAliveEnemies =
            Mathf.Max(
                1,
                maxAliveEnemies
            );

        spawnInterval =
            Mathf.Max(
                0.05f,
                spawnInterval
            );

        spawnCount =
            Mathf.Max(
                1,
                spawnCount
            );

        minOutsideDistance =
            Mathf.Max(
                0.1f,
                minOutsideDistance
            );

        maxOutsideDistance =
            Mathf.Max(
                minOutsideDistance,
                maxOutsideDistance
            );

        minDistanceFromRibel =
            Mathf.Max(
                0f,
                minDistanceFromRibel
            );

        minDistanceFromSummons =
            Mathf.Max(
                0f,
                minDistanceFromSummons
            );

        spawnCheckRadius =
            Mathf.Max(
                0.05f,
                spawnCheckRadius
            );

        maxSpawnAttempts =
            Mathf.Max(
                1,
                maxSpawnAttempts
            );
    }
#endif
}