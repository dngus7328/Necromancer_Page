using System.Collections.Generic;
using UnityEngine;

public class MinimapEnemyTracker : MonoBehaviour
{
    [Header("�̴ϸ� ����")]
    [SerializeField] private RectTransform minimapRect;

    [SerializeField] private RectTransform unitRoot;

    [Header("�� Prefab")]
    [SerializeField] private GameObject ribelDotPrefab;
    [SerializeField] private GameObject summonDotPrefab;
    [SerializeField] private GameObject enemyDotPrefab;

    [Header("����")]
    [SerializeField] private Transform ribel;

    [Header("�̴ϸ� ���� ǥ�� ����")]
    [Tooltip("���� ���� �̴ϸ� ��ü ���� ǥ�� ����")]
    [SerializeField] private float worldWidth = 28f;

    [Tooltip("���� ���� �̴ϸ� ��ü ���� ǥ�� ����")]
    [SerializeField] private float worldHeight = 18f;

    [Header("����")]
    [Tooltip("�� ���� ����/��� Ȯ�� �ֱ�")]
    [SerializeField] private float refreshInterval = 0.1f;

    private RectTransform ribelDot;

    private float refreshTimer;

    private readonly Dictionary<SummonUnitBase, RectTransform> summonDots =
        new Dictionary<SummonUnitBase, RectTransform>();

    private readonly Dictionary<EnemyUnitBase, RectTransform> enemyDots =
        new Dictionary<EnemyUnitBase, RectTransform>();

    private void Start()
    {
        FindRibel();

        CreateRibelDot();

        RefreshAllUnits();
    }

    private void Update()
    {
        refreshTimer -= Time.deltaTime;

        if (refreshTimer <= 0f)
        {
            refreshTimer = refreshInterval;

            RefreshAllUnits();
        }

        UpdateRibelDot();
        UpdateSummonDots();
        UpdateEnemyDots();
    }

    // =========================================================
    // ���� ã��
    // =========================================================

    private void FindRibel()
    {
        if (ribel != null)
        {
            return;
        }

        GameObject ribelObject =
            GameObject.FindGameObjectWithTag("Player");

        if (ribelObject != null)
        {
            ribel = ribelObject.transform;
        }
    }

    // =========================================================
    // ���� �� ����
    // =========================================================

    private void CreateRibelDot()
    {
        if (ribelDotPrefab == null ||
            unitRoot == null ||
            ribelDot != null)
        {
            return;
        }

        GameObject dotObject =
            Instantiate(
                ribelDotPrefab,
                unitRoot
            );

        ribelDot =
            dotObject.GetComponent<RectTransform>();
    }

    // =========================================================
    // ��ü ���� ����
    // =========================================================

    private void RefreshAllUnits()
    {
        RefreshSummons();
        RefreshEnemies();
    }

    // =========================================================
    // ��ȯ�� ���
    // =========================================================

    private void RefreshSummons()
    {
        SummonUnitBase[] summons =
            FindObjectsOfType<SummonUnitBase>();

        for (int i = 0; i < summons.Length; i++)
        {
            SummonUnitBase summon =
                summons[i];

            if (summon == null)
            {
                continue;
            }

            if (!summonDots.ContainsKey(summon))
            {
                CreateSummonDot(summon);
            }
        }

        List<SummonUnitBase> removeList =
            new List<SummonUnitBase>();

        foreach (
            KeyValuePair<SummonUnitBase, RectTransform> pair
            in summonDots)
        {
            if (pair.Key == null)
            {
                if (pair.Value != null)
                {
                    Destroy(pair.Value.gameObject);
                }

                removeList.Add(pair.Key);
            }
        }

        for (int i = 0; i < removeList.Count; i++)
        {
            summonDots.Remove(removeList[i]);
        }
    }

    private void CreateSummonDot(
        SummonUnitBase summon)
    {
        if (summonDotPrefab == null ||
            unitRoot == null)
        {
            return;
        }

        GameObject dotObject =
            Instantiate(
                summonDotPrefab,
                unitRoot
            );

        RectTransform dot =
            dotObject.GetComponent<RectTransform>();

        if (dot != null)
        {
            summonDots.Add(
                summon,
                dot
            );
        }
    }

    // =========================================================
    // �� ���
    // =========================================================

    private void RefreshEnemies()
    {
        EnemyUnitBase[] enemies =
            FindObjectsOfType<EnemyUnitBase>();

        for (int i = 0; i < enemies.Length; i++)
        {
            EnemyUnitBase enemy =
                enemies[i];

            if (enemy == null)
            {
                continue;
            }

            if (!enemyDots.ContainsKey(enemy))
            {
                CreateEnemyDot(enemy);
            }
        }

        List<EnemyUnitBase> removeList =
            new List<EnemyUnitBase>();

        foreach (
            KeyValuePair<EnemyUnitBase, RectTransform> pair
            in enemyDots)
        {
            if (pair.Key == null)
            {
                if (pair.Value != null)
                {
                    Destroy(pair.Value.gameObject);
                }

                removeList.Add(pair.Key);
            }
        }

        for (int i = 0; i < removeList.Count; i++)
        {
            enemyDots.Remove(removeList[i]);
        }
    }

    private void CreateEnemyDot(
        EnemyUnitBase enemy)
    {
        if (enemyDotPrefab == null ||
            unitRoot == null)
        {
            return;
        }

        GameObject dotObject =
            Instantiate(
                enemyDotPrefab,
                unitRoot
            );

        RectTransform dot =
            dotObject.GetComponent<RectTransform>();

        if (dot != null)
        {
            enemyDots.Add(
                enemy,
                dot
            );
        }
    }

    // =========================================================
    // ���� ��
    // =========================================================

    private void UpdateRibelDot()
    {
        if (ribelDot == null)
        {
            return;
        }

        // ���� �߽��� �̴ϸ�
        ribelDot.anchoredPosition =
            Vector2.zero;
    }

    // =========================================================
    // ��ȯ�� ��
    // =========================================================

    private void UpdateSummonDots()
    {
        if (ribel == null)
        {
            FindRibel();

            if (ribel == null)
            {
                return;
            }
        }

        foreach (
            KeyValuePair<SummonUnitBase, RectTransform> pair
            in summonDots)
        {
            if (pair.Key == null ||
                pair.Value == null)
            {
                continue;
            }

            Vector2 relative =
                (Vector2)pair.Key.transform.position -
                (Vector2)ribel.position;

            // ��ȯ���� ���� ����ó�� �̴ϸ� �������� ����
            Vector2 minimapPosition =
                RelativeToMinimapPositionClamped(
                    relative
                );

            pair.Value.gameObject.SetActive(true);

            pair.Value.anchoredPosition =
                minimapPosition;
        }
    }

    // =========================================================
    // �� ��
    // =========================================================

    private void UpdateEnemyDots()
    {
        if (ribel == null)
        {
            FindRibel();

            if (ribel == null)
            {
                return;
            }
        }

        float halfWorldWidth =
            worldWidth * 0.5f;

        float halfWorldHeight =
            worldHeight * 0.5f;

        foreach (
            KeyValuePair<EnemyUnitBase, RectTransform> pair
            in enemyDots)
        {
            if (pair.Key == null ||
                pair.Value == null)
            {
                continue;
            }

            Vector2 relative =
                (Vector2)pair.Key.transform.position -
                (Vector2)ribel.position;

            // =================================================
            // �ٽ�:
            // �̴ϸ� ���� �� ���� �׵θ��� ������ �ʰ� �����.
            // =================================================

            bool outside =
                Mathf.Abs(relative.x) >
                    halfWorldWidth ||
                Mathf.Abs(relative.y) >
                    halfWorldHeight;

            if (outside)
            {
                pair.Value.gameObject.SetActive(false);
                continue;
            }

            // ������ ������� �ٽ� ���� �ȿ� ������ ǥ��
            if (!pair.Value.gameObject.activeSelf)
            {
                pair.Value.gameObject.SetActive(true);
            }

            pair.Value.anchoredPosition =
                RelativeToMinimapPosition(
                    relative
                );
        }
    }

    // =========================================================
    // ���� �� ��ǥ �� �̴ϸ�
    // =========================================================

    private Vector2 RelativeToMinimapPosition(
        Vector2 relative)
    {
        if (minimapRect == null)
        {
            return Vector2.zero;
        }

        float halfWorldWidth =
            worldWidth * 0.5f;

        float halfWorldHeight =
            worldHeight * 0.5f;

        float normalizedX =
            relative.x /
            halfWorldWidth;

        float normalizedY =
            relative.y /
            halfWorldHeight;

        float halfMinimapWidth =
            minimapRect.rect.width *
            0.5f;

        float halfMinimapHeight =
            minimapRect.rect.height *
            0.5f;

        return new Vector2(
            normalizedX *
                halfMinimapWidth,

            normalizedY *
                halfMinimapHeight
        );
    }

    // =========================================================
    // Clamp ���
    // ��ȯ�� � ���
    // =========================================================

    private Vector2 RelativeToMinimapPositionClamped(
        Vector2 relative)
    {
        if (minimapRect == null)
        {
            return Vector2.zero;
        }

        float halfWorldWidth =
            worldWidth * 0.5f;

        float halfWorldHeight =
            worldHeight * 0.5f;

        float normalizedX =
            relative.x /
            halfWorldWidth;

        float normalizedY =
            relative.y /
            halfWorldHeight;

        normalizedX =
            Mathf.Clamp(
                normalizedX,
                -1f,
                1f
            );

        normalizedY =
            Mathf.Clamp(
                normalizedY,
                -1f,
                1f
            );

        float halfMinimapWidth =
            minimapRect.rect.width *
            0.5f;

        float halfMinimapHeight =
            minimapRect.rect.height *
            0.5f;

        return new Vector2(
            normalizedX *
                halfMinimapWidth,

            normalizedY *
                halfMinimapHeight
        );
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        worldWidth =
            Mathf.Max(
                0.1f,
                worldWidth
            );

        worldHeight =
            Mathf.Max(
                0.1f,
                worldHeight
            );

        refreshInterval =
            Mathf.Max(
                0.02f,
                refreshInterval
            );
    }
#endif
}