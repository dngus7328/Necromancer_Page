using UnityEngine;
using UnityEngine.UI;

public class PlayerStatusUI : MonoBehaviour
{
    [Header("����")]
    [SerializeField] private RibelHealth ribelHealth;

    [Header("HP")]
    [SerializeField] private Image healthFill;

    [Header("����")]
    [SerializeField] private Image manaFill;

    [Header("������ �ε巯��")]
    [Tooltip("���� Ŭ���� �������� �� ������ ���󰩴ϴ�.")]
    [SerializeField] private float healthSmoothSpeed = 6f;

    [Tooltip("���� Ŭ���� �������� �� ������ ���󰩴ϴ�.")]
    [SerializeField] private float manaSmoothSpeed = 6f;

    private float targetHealthRatio = 1f;
    private float targetManaRatio = 1f;

    private void Start()
    {
        InitializeGaugeValues();
    }

    private void Update()
    {
        UpdateTargetValues();
        UpdateGaugeAnimation();
    }

    // =========================================================
    // ������ �� ���� ������ ��� ����
    // =========================================================

    private void InitializeGaugeValues()
    {
        if (ribelHealth != null &&
            healthFill != null &&
            ribelHealth.MaxHealth > 0f)
        {
            targetHealthRatio =
                Mathf.Clamp01(
                    ribelHealth.CurrentHealth /
                    ribelHealth.MaxHealth
                );

            healthFill.fillAmount =
                targetHealthRatio;
        }

        if (manaFill != null &&
            SummonManager.Instance != null &&
            SummonManager.Instance.MaxMana > 0f)
        {
            targetManaRatio =
                Mathf.Clamp01(
                    SummonManager.Instance.CurrentMana /
                    SummonManager.Instance.MaxMana
                );

            manaFill.fillAmount =
                targetManaRatio;
        }
    }

    // =========================================================
    // ���� �� �б�
    // =========================================================

    private void UpdateTargetValues()
    {
        if (ribelHealth != null &&
            ribelHealth.MaxHealth > 0f)
        {
            targetHealthRatio =
                Mathf.Clamp01(
                    ribelHealth.CurrentHealth /
                    ribelHealth.MaxHealth
                );
        }

        if (SummonManager.Instance != null &&
            SummonManager.Instance.MaxMana > 0f)
        {
            targetManaRatio =
                Mathf.Clamp01(
                    SummonManager.Instance.CurrentMana /
                    SummonManager.Instance.MaxMana
                );
        }
    }

    // =========================================================
    // �ε巴�� ���� ������ �̵�
    // =========================================================

    private void UpdateGaugeAnimation()
    {
        if (healthFill != null)
        {
            healthFill.fillAmount =
                Mathf.Lerp(
                    healthFill.fillAmount,
                    targetHealthRatio,
                    1f - Mathf.Exp(
                        -healthSmoothSpeed * Time.deltaTime
                    )
                );
        }

        if (manaFill != null)
        {
            manaFill.fillAmount =
                Mathf.Lerp(
                    manaFill.fillAmount,
                    targetManaRatio,
                    1f - Mathf.Exp(
                        -manaSmoothSpeed * Time.deltaTime
                    )
                );
        }
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        healthSmoothSpeed =
            Mathf.Max(0.1f, healthSmoothSpeed);

        manaSmoothSpeed =
            Mathf.Max(0.1f, manaSmoothSpeed);
    }
#endif
}