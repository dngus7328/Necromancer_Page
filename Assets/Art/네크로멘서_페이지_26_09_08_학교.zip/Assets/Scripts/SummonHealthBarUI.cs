using UnityEngine;

public class SummonHealthBar : MonoBehaviour
{
    [Header("���")]
    [SerializeField] private SummonUnitBase summon;

    [Header("ü�¹�")]
    [SerializeField] private Transform fill;

    [Tooltip("ü���� ���� á�� �� Fill�� X ũ��")]
    [SerializeField] private float fullWidth = 0.8f;

    private Vector3 originalFillScale;
    private Vector3 originalFillPosition;

    private void Awake()
    {
        if (summon == null)
        {
            summon =
                GetComponentInParent<SummonUnitBase>();
        }

        if (fill != null)
        {
            originalFillScale = fill.localScale;
            originalFillPosition = fill.localPosition;
        }
    }

    private void LateUpdate()
    {
        UpdateHealthBar();
    }

    private void UpdateHealthBar()
    {
        if (summon == null || fill == null)
        {
            return;
        }

        if (summon.MaxHealth <= 0f)
        {
            return;
        }

        float ratio =
            Mathf.Clamp01(
                summon.CurrentHealth /
                summon.MaxHealth
            );

        Vector3 newScale =
            originalFillScale;

        newScale.x =
            originalFillScale.x * ratio;

        fill.localScale = newScale;

        // ��� Pivot�̾
        // ������ �κи� �پ�� ��ó�� ���̵��� ��ġ ����
        float lostWidth =
            fullWidth * (1f - ratio);

        Vector3 newPosition =
            originalFillPosition;

        newPosition.x =
            originalFillPosition.x -
            (lostWidth * 0.5f);

        fill.localPosition =
            newPosition;
    }
}