using UnityEngine;

public class CommandRangeVisual : MonoBehaviour
{
    public static CommandRangeVisual Instance { get; private set; }

    [Header("���� ���� ����")]
    [SerializeField] private float commandRange = 9f;

    [Header("���� ���� ��")]
    [Tooltip("Ribel �Ʒ��� �̹� ������ CommandRangeCircle")]
    [SerializeField] private GameObject commandRangeCircle;

    [Tooltip("CommandRangeCircle�� SpriteRenderer")]
    [SerializeField] private SpriteRenderer circleRenderer;

    [Header("���� �� ��")]
    [SerializeField]
    private Color rallyColor =
        new Color(
            0.15f,
            0.75f,
            1f,
            0.25f
        );

    public float CommandRange =>
        commandRange;

    private void Awake()
    {
        if (Instance != null &&
            Instance != this)
        {
            Destroy(this);
            return;
        }

        Instance = this;
    }

    private void Start()
    {
        HideRange();
    }

    // =========================================================
    // ���� ���� ���� ����
    // =========================================================

    public bool IsInsideRange(Vector2 worldPosition)
    {
        float distance =
            Vector2.Distance(
                transform.position,
                worldPosition
            );

        return distance <= commandRange;
    }

    // =========================================================
    // Q Ȧ�� �� ǥ��
    // =========================================================

    public void ShowRallyRange()
    {
        if (commandRangeCircle == null)
        {
            return;
        }

        commandRangeCircle.SetActive(true);

        if (circleRenderer != null)
        {
            circleRenderer.color =
                rallyColor;
        }
    }

    // =========================================================
    // �����
    // =========================================================

    public void HideRange()
    {
        if (commandRangeCircle != null)
        {
            commandRangeCircle.SetActive(false);
        }
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        commandRange =
            Mathf.Max(
                0.1f,
                commandRange
            );
    }
#endif
}